from setuptools import setup, find_packages

setup(
    name='deep_sheep',
    version='0.1',
    description='Custom training package for DeepSheep on Vertex AI.',
    author='Will Glad',
    packages=find_packages()
)
